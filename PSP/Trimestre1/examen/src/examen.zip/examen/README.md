# ...TEORICAS
## 2
No se pueden ejecutar todos a la vez ya que, como expliqué en el código
de la _Main_ necesito que se "seteen" los valores que piden en el apartado E y 
D antes de imprimirlos. Si no establezco un orden de ejecucion para los hilos
de los anteriores apartados a estos, el resultado de los 2 últimos apartados
va a imprimir nulos o errores

