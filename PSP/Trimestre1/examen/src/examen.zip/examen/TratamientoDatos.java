/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen;

/**
 *
 * @author dam2
 */
public class TratamientoDatos {

    public void imprimirArrayString(String[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("[" + i + "] = " + arreglo[i]);
        }
    }

    public void imprimirArrayCaracteres(char[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("[" + i + "] = " + arreglo[i]);
        }
    }

}
