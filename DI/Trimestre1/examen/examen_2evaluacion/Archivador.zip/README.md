# Usabilidad mejoras:
1. Iconos coherentes con la accion a realizar por un boton.
2. Mensajes de confirmacion antes de realizar una accion
como por ejemplo de borrado o eliminacion.
3. Implementar shortcuts o teclas de acceso rapido
4. Mensajes de confirmacion visual al realizar una accion
5. Poner botones o formas para revertir un paso.
6. Cambiar el tipo de cursor en funcion del boton, de la parte
de la interfaz, de la accion a realizar etc. POr ejemplo una manito
para mover cosas, un mano señalando para aceptar algo etc