# Exercicio 16 - XMLwriter
ler dende o  ficheiro que creache no  exercicio Serializacion2 os obxectos que almacenaches nel 
e almacenaos en formato XML nun ficheiro denominado "products.xml"

>IMPORTANTE: debes importar o proxecto denominado serialiazion2 para usar a sua clase Product para ler os obxectos que almacenaches en dito exercicio  , NON debes copiar e pegar a clase Product en ningún caso.


## Respuesta
Para importar serializacion2 tengo que crear el jar en dicho proyecto con `clean and build` y luego
lo importo (se localiza en la carpeta "dist") a la carpeta de Libreries del este proyecto.


